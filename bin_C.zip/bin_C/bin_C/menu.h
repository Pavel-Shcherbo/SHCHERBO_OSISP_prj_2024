#ifndef MENU_H
#define MENU_H

#include "functions.h"

void menu();

#endif /* MENU_H */
