#ifndef BIN_COMMANDS_H
#define BIN_COMMANDS_H

void addToBasket(const char* filename);
void restoreFromBasket();
void clearBasket();
void displayBasketInfo();

#endif /* BIN_COMMANDS_H */
