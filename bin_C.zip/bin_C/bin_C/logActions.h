#ifndef LOG_ACTIONS_H
#define LOG_ACTIONS_H

void logAction(const char* action, const char* filename);

#endif /* LOG_ACTIONS_H */
